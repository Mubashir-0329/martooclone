var swiper = new Swiper(".mySwiper", {
    // slidesPerView:"6",
    // spacebetween:5  ,
    // autoplay:{
    //     delay:2500,
    //     disableoninteraction:false,
    // },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
         // berak point for 386px
         376: {
          slidesPerView: 2 ,
          spaceBetween: 0
  
        },
      // berak point for 586px
      576: {
        slidesPerView: 3 ,
        spaceBetween: 0

      },
      // when window width is >= 320px
      768: {
        slidesPerView: 4,
        spaceBetween: 10
      },
      // when window width is >= 480px
      1024: {
        slidesPerView: 6,
        spaceBetween: 3
      },
      // when window width is >= 640px
      2100: {
        slidesPerView: 9,
        spaceBetween: 5
      }
    }
  });
  // ......................................................
  // swipper2
 

  var swiper = new Swiper(".mSwiper", {
    slidesPerView: 4,
    spaceBetween: 0,
    // pagination: {
    //   el: ".swiper-pagination",
    //   clickable: true,
    // },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      100:{
        slidesPerView: 1,
        spaceBetween: 10

      },
      // berak point for 386px
      376: {
       slidesPerView: 2,
       spaceBetween: 10

     },
   // berak point for 586px
   576: {
     slidesPerView: 2 ,
     spaceBetween: 0

   },
   // when window width is >= 320px
   768: {
     slidesPerView: 3,
     spaceBetween: 10
   },
   // when window width is >= 480px
   1024: {
     slidesPerView: 4,
     spaceBetween: 0
   },
   // when window width is >= 640px
   1500: {
     slidesPerView: 5,
     spaceBetween: 5
   }
 }
  });